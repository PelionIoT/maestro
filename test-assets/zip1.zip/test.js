console.log("this is a deviceJS script")

var n = 0

setInterval(function(){
	console.log("deviceJS script test.js " + n)
	n++
},1000)

